# Cam-Hack
Advance Method To Hack Mobile Or Pc Front (Selfie) Camera With A Link.
<br>
See This Image :-https://ibb.co/RbYvWG8

# How it works?
<p>The tool generates a malicious HTTPS page using Serveo or Ngrok Port Forwarding methods, and a javascript code to cam requests using MediaDevices.getUserMedia. </p>

<p>The MediaDevices.getUserMedia() method prompts the user for permission to use a media input which produces a MediaStream with tracks containing the requested types of media. That stream can include, for example, a video track (produced by either a hardware or virtual video source such as a camera, video recording device, screen sharing service, and so forth), an audio track (similarly, produced by a physical or virtual audio source like a microphone, A/D converter, or the like), and possibly other track types. </p>

[See more about MediaDEvices.getUserMedia() here](https://developer.mozilla.org/en-US/docs/Web/API/MediaDevices/getUserMedia)
<p> To convince the target to grant permissions to access the cam, the page uses a javascript code made by https://github.com/wybiral that turns the favicon into a cam stream.</p>

# New features
<p>01. Work in Termux and Kali Linux</p>
<p>02. Distract Victim To your favovrite website</p>
<p>03. Hide your link with 4th url shortener</p>
<p>+-+ You will get victim .../p>
<p>04. Ip</p>
<p>05. User-Agent</p>
<p>06. Hostname</p>
<p>07. Reverse DNS</p>
<p>08. Continent</p>
<p>09. Country</p>
<p>10. Capital</p>
<p>11. State</p>
<p>12. City Location</p>
<p>13. Country Language</p>
<p>14. Country IDD Code</p>
<p>15. Time Zone</p>
<p>16. Local Time (Now)</p>
<p>17. Sunrise / Sunset (Today)</p>
<p>18. ISP</p>
<p>19. AS Number</p>
<p>20. Address Speed</p>
<p>21. Currency</p>
<p> And More...</p>
          
# Installing (Kali Linux/Termux):

```
git clone https://github.com/Hack-The-World-With-Tech/Cam-Hack.git
cd Cam-Hack
ls
chmod +x *
ls
bash camhack.sh
```
# Important
<p> Before use Serveo You must check that Is Serveo enable. Check it in this site http://serveo.net/ </p>
<p> If you use Ngrok in termux, You must enable Hotspot. Otherwise Ngrok doesn't generate a link. </p>
<p> If you use any part from this code, giving me the credits. Read the Lincense!</p>

# Contact
<p> Any Problem Or Issues Email for this Email Address Or My Telegram Bot</p>
<p> Email Address :- techwithsasi@gmail.com </p>
<p> Telegram Bot  :- http://t.me/HackTheWorldWithTech_bot
<p> This tool created By |SASI| </p>
